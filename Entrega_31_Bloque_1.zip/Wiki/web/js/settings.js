function loadSettings(){
    console.log("Cargar configuración");
}
function saveSettings(){
    console.log("Guardar configuración");
}
