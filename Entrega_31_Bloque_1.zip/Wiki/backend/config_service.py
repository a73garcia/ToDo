import json
from pathlib import Path

CONFIG_FILE = Path(__file__).resolve().parent.parent/"config"/"settings.json"

DEFAULT_CONFIG = {
    "wiki_title": "Wiki Procedimientos",
    "attachments_path": "attachments",
    "documents_path": "documents",
    "templates_path": "templates",
    "category_prefix_length": 3,
    "theme": "light"
}

def load_config():
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))

def save_config(data):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
