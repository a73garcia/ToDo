Entrega 31

- Servicio de configuración global.
- Archivo settings.json.
- Panel de configuración.
- Base preparada para ampliar preferencias de la aplicación.
