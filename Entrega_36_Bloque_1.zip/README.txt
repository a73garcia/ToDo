Entrega 36

- Gestión inicial de imágenes.
- Tabla images.
- Galería de miniaturas.
- Base preparada para insertar imágenes dentro de documentos Markdown.
