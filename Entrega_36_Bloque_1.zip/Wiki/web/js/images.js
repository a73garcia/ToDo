function insertImage(){
    console.log("Insertar imagen");
}
function previewImage(path){
    console.log("Vista previa:",path);
}
function removeImage(id){
    console.log("Eliminar imagen",id);
}
