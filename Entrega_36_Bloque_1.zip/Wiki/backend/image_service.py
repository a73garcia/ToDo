import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def ensure_table():
    con=sqlite3.connect(DB)
    con.execute('''
    CREATE TABLE IF NOT EXISTS images(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rfc TEXT NOT NULL,
        filename TEXT NOT NULL,
        path TEXT NOT NULL,
        alt_text TEXT,
        created_at TEXT
    )
    ''')
    con.commit()
    con.close()
