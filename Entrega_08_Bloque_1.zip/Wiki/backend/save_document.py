from pathlib import Path

DOCS = Path(__file__).resolve().parent.parent / "documents"

def save_document(rfc:str, content:str):
    DOCS.mkdir(exist_ok=True)
    file = DOCS / f"{rfc}.md"
    file.write_text(content, encoding="utf-8")
    return file
