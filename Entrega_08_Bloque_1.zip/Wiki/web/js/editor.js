function updateStatus(msg){
    const s=document.getElementById('status');
    if(s) s.textContent=msg;
}

function newDocumentReady(){
    updateStatus("Documento preparado. Pendiente de guardar.");
}

window.addEventListener("DOMContentLoaded", newDocumentReady);
