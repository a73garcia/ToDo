Entrega 08
- Barra de estado del editor.
- Estilos básicos de la barra de herramientas.
- Servicio inicial para guardar documentos Markdown por RFC.
