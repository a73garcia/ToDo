#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wiki Procedimientos - Launcher
"""

from pathlib import Path
import os
import sys
import webbrowser
import threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

HOST="127.0.0.1"
PORT=8080

BASE_DIR=Path(__file__).resolve().parent
WEB_DIR=BASE_DIR/"web"

class WikiRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(WEB_DIR),**kwargs)

def open_browser():
    webbrowser.open(f"http://{HOST}:{PORT}")

def main():
    if not WEB_DIR.exists():
        print("ERROR: No existe la carpeta web")
        sys.exit(1)

    os.chdir(WEB_DIR)

    server=ThreadingHTTPServer((HOST,PORT),WikiRequestHandler)
    threading.Timer(1.2,open_browser).start()

    print("Wiki Procedimientos iniciado")
    server.serve_forever()

if __name__=="__main__":
    main()
