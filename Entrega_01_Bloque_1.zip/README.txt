Entrega 01 - Bloque 1
Contiene el primer archivo del proyecto (launcher.py).
Las siguientes entregas añadirán el resto de archivos.
