import sqlite3
from pathlib import Path

DB=Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def get_dashboard_summary():
    con=sqlite3.connect(DB)
    cur=con.cursor()
    data={}
    for table,key in [("documents","documents"),
                      ("categories","categories"),
                      ("templates","templates"),
                      ("attachments","attachments")]:
        try:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            data[key]=cur.fetchone()[0]
        except sqlite3.Error:
            data[key]=0
    con.close()
    return data
