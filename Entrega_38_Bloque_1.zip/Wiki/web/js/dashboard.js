function loadDashboard(){
    console.log("Cargar dashboard");
}
function refreshDashboard(){
    console.log("Actualizar dashboard");
}
