Entrega 38

- Dashboard inicial.
- Resumen de documentos, categorías, plantillas y adjuntos.
- Tarjetas preparadas para estadísticas.
- Base para añadir actividad reciente y documentos más consultados.
