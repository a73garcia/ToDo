async function saveVersion(){
 const comment=prompt("Comentario de la versión:")||"";
 console.log("Guardar versión",comment);
}
function showHistory(rfc){
 console.log("Mostrar historial",rfc);
}
