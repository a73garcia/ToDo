import sqlite3
from pathlib import Path
from datetime import datetime

DB=Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def ensure_table():
    con=sqlite3.connect(DB)
    cur=con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS document_versions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rfc TEXT,
      version TEXT,
      created_at TEXT,
      comment TEXT,
      content TEXT
    )""")
    con.commit(); con.close()

def save_version(rfc,version,comment,content):
    ensure_table()
    con=sqlite3.connect(DB)
    cur=con.cursor()
    cur.execute("INSERT INTO document_versions(rfc,version,created_at,comment,content) VALUES(?,?,?,?,?)",
                (rfc,version,datetime.now().isoformat(timespec='seconds'),comment,content))
    con.commit(); con.close()
