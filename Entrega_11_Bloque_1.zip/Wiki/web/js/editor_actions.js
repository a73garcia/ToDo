async function saveCurrentDocument(){

    const data={
        rfc:document.getElementById('rfc').textContent,
        title:document.getElementById('title').value,
        category:document.getElementById('category').value,
        type:document.getElementById('docType').value,
        content:document.getElementById('editor').value
    };

    console.log("Guardar documento",data);

    alert("La conexión con Python se realizará en la siguiente integración.");
}
