from pathlib import Path
import sqlite3

DB = Path(__file__).resolve().parent.parent / "database" / "wiki.db"

def save_document(rfc, titulo, categoria, tipo, contenido):
    con = sqlite3.connect(DB)
    cur = con.cursor()

    cur.execute("""
        UPDATE documents
           SET titulo=?,
               categoria=?,
               tipo=?
         WHERE rfc=?
    """, (titulo, categoria, tipo, rfc))

    con.commit()
    con.close()

    docs = Path(__file__).resolve().parent.parent / "documents"
    docs.mkdir(exist_ok=True)

    (docs / f"{rfc}.md").write_text(contenido, encoding="utf-8")

    return True
