from pathlib import Path
import zipfile

def create_backup(source_folder, output_zip):
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for f in Path(source_folder).rglob("*"):
            if f.is_file():
                z.write(f, f.relative_to(source_folder))

def restore_backup(zip_file, destination):
    with zipfile.ZipFile(zip_file, "r") as z:
        z.extractall(destination)
