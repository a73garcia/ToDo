Entrega 30

- Servicio de copia de seguridad.
- Restauración desde archivo ZIP.
- Panel inicial para gestionar backups.
- Base para incluir base de datos, documentos y adjuntos.
