function addAttachment(){
    console.log("Añadir adjunto");
}
function removeAttachment(id){
    console.log("Eliminar adjunto", id);
}
function openAttachment(path){
    console.log("Abrir", path);
}
