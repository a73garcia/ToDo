import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent.parent / "database" / "wiki.db"

def ensure_table():
    con = sqlite3.connect(DB)
    con.execute('''
    CREATE TABLE IF NOT EXISTS attachments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rfc TEXT NOT NULL,
        name TEXT NOT NULL,
        path TEXT NOT NULL,
        attachment_type TEXT NOT NULL,
        created_at TEXT
    )
    ''')
    con.commit()
    con.close()
