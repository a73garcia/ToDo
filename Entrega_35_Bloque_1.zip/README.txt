Entrega 35

- Gestión inicial de adjuntos.
- Tabla attachments.
- Soporte para archivos locales y enlaces SharePoint.
- Panel preparado para listar, abrir y eliminar adjuntos.
