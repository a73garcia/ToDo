from database.repository import list_documents

def refresh_document_list():
    return list_documents()
