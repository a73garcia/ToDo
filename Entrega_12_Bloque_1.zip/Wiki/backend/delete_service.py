import sqlite3
from pathlib import Path

DB=Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def delete_document(rfc):
    con=sqlite3.connect(DB)
    cur=con.cursor()
    cur.execute("DELETE FROM documents WHERE rfc=?", (rfc,))
    con.commit()
    deleted=cur.rowcount
    con.close()
    return deleted>0
