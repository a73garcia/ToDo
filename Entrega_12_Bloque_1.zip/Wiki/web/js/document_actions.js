async function refreshDocuments(){
    console.log("Actualizar listado");
    // Integración con backend en siguiente fase
}

async function deleteCurrentDocument(rfc){
    if(!confirm("¿Eliminar el documento "+rfc+"?")) return;
    console.log("Eliminar", rfc);
}
