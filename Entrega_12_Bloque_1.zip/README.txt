Entrega 12

- Servicio de actualización del listado.
- Servicio de eliminación de documentos.
- Acciones JavaScript para refrescar y eliminar.
- Preparado para enlazar con el backend HTTP local.
