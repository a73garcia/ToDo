Entrega 34

- Gestión de plantillas.
- Tabla templates.
- Plantilla Markdown de ejemplo.
- Base preparada para asociar plantillas a tipos de documento.
