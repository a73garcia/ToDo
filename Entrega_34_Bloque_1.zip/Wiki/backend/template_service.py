import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def ensure_table():
    con = sqlite3.connect(DB)
    con.execute('''CREATE TABLE IF NOT EXISTS templates(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        description TEXT,
        filename TEXT,
        document_type_id INTEGER
    )''')
    con.commit()
    con.close()
