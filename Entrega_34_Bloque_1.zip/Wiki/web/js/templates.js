function loadTemplates(){
    console.log("Cargar plantillas");
}
function saveTemplate(){
    console.log("Guardar plantilla");
}
function importTemplate(){
    console.log("Importar plantilla");
}
