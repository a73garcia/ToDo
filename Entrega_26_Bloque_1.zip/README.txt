Entrega 26

- Comparación de versiones mediante difflib.
- Visor de diferencias.
- Coloreado básico de líneas añadidas y eliminadas.
- Base preparada para restaurar versiones desde el historial.
