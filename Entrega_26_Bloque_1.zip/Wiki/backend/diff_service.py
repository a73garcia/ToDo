import difflib

def compare_versions(old_text, new_text):
    return list(difflib.unified_diff(
        old_text.splitlines(),
        new_text.splitlines(),
        fromfile="Anterior",
        tofile="Actual",
        lineterm=""
    ))
