function renderDiff(lines){
    const panel=document.getElementById("diffView");
    if(!panel) return;
    panel.innerHTML="";
    lines.forEach(line=>{
        const div=document.createElement("div");
        if(line.startsWith("+")) div.className="diff-add";
        else if(line.startsWith("-")) div.className="diff-del";
        else div.className="diff-line";
        div.textContent=line;
        panel.appendChild(div);
    });
}
