from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from database.repository import list_documents, get_document

class WikiAPI(BaseHTTPRequestHandler):

    def _send(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_GET(self):
        if self.path == "/api/documents":
            self._send(list_documents())
            return

        if self.path.startswith("/api/document/"):
            rfc=self.path.split("/")[-1]
            doc=get_document(rfc)
            self._send(doc if doc else {"error":"No encontrado"}, 200 if doc else 404)
            return

        self._send({"error":"Ruta no válida"},404)

def run(host="127.0.0.1", port=8080):
    HTTPServer((host,port), WikiAPI).serve_forever()

if __name__=="__main__":
    run()
