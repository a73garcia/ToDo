async function apiGetDocuments(){
    const r=await fetch('/api/documents');
    return await r.json();
}

async function apiOpenDocument(rfc){
    const r=await fetch('/api/document/'+encodeURIComponent(rfc));
    return await r.json();
}
