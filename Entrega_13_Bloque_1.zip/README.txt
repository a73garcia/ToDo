Entrega 13

- API HTTP local basada en http.server.
- Endpoint GET /api/documents.
- Endpoint GET /api/document/{RFC}.
- Cliente JavaScript para consumir la API.
