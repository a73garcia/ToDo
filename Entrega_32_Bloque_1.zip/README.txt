Entrega 32

- Gestión de categorías.
- Tabla categories.
- Panel de administración.
- Base para códigos RFC y ordenación.
