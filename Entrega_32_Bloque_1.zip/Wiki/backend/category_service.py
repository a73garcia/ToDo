import sqlite3
from pathlib import Path
DB=Path(__file__).resolve().parent.parent/'database'/'wiki.db'

def ensure_table():
    con=sqlite3.connect(DB)
    con.execute('''CREATE TABLE IF NOT EXISTS categories(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT,
    description TEXT,
    sort_order INTEGER DEFAULT 0)''')
    con.commit();con.close()
