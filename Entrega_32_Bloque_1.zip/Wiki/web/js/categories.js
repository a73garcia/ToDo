function loadCategories(){console.log('Cargar categorías');}
function saveCategory(){console.log('Guardar categoría');}
function deleteCategory(id){console.log('Eliminar',id);}