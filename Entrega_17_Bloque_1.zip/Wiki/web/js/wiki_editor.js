
function insertMarkdown(before, after=""){
    const editor=document.getElementById("editor");
    const start=editor.selectionStart;
    const end=editor.selectionEnd;
    const txt=editor.value;
    editor.value=txt.substring(0,start)+before+txt.substring(start,end)+after+txt.substring(end);
    editor.focus();
}
function bold(){insertMarkdown("**","**");}
function italic(){insertMarkdown("*","*");}
function code(){insertMarkdown("\n```\n","\n```\n");}
