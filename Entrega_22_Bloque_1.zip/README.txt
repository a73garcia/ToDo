Entrega 22

- Servicio de búsqueda global.
- Barra de búsqueda en tiempo real.
- Preparado para integrar el endpoint /api/search.
- Base para búsquedas por RFC, título, categoría y tipo.
