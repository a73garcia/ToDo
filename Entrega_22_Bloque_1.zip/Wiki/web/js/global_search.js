async function searchWiki(){
    const txt=document.getElementById("globalSearch").value.trim();

    if(txt===""){
        loadDocuments();
        return;
    }

    console.log("Buscar:",txt);
    // Próxima entrega: llamada a /api/search
}

function clearSearch(){
    document.getElementById("globalSearch").value="";
    loadDocuments();
}
