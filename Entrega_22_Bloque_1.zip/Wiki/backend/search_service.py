import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent.parent / "database" / "wiki.db"

def search_documents(text):
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    cur = con.cursor()

    like = f"%{text}%"
    cur.execute("""
        SELECT rfc,titulo,categoria,tipo
        FROM documents
        WHERE rfc LIKE ?
           OR titulo LIKE ?
           OR categoria LIKE ?
           OR tipo LIKE ?
        ORDER BY rfc DESC
    """, (like, like, like, like))

    rows = [dict(r) for r in cur.fetchall()]
    con.close()
    return rows
