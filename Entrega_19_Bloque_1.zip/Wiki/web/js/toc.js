
function buildTOC(){
 const editor=document.getElementById("editor");
 const toc=document.getElementById("toc");
 if(!editor||!toc)return;
 let html="<h3>Contenido</h3><ul>";
 editor.value.split("\n").forEach((l,i)=>{
   const m=l.match(/^(#{1,3})\s+(.*)$/);
   if(m){html+=`<li class="h${m[1].length}"><a href="#" onclick="gotoLine(${i})">${m[2]}</a></li>`;}
 });
 toc.innerHTML=html+"</ul>";
}
function gotoLine(line){
 const e=document.getElementById("editor");
 const lines=e.value.split("\n");
 let pos=0;
 for(let i=0;i<line;i++)pos+=lines[i].length+1;
 e.focus();e.setSelectionRange(pos,pos);
}
window.addEventListener("DOMContentLoaded",()=>{
 const e=document.getElementById("editor");
 if(e){e.addEventListener("input",buildTOC);buildTOC();}
});
