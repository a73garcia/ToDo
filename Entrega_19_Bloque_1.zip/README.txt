Entrega 19

- Tabla de contenidos automática.
- Navegación por encabezados Markdown.
- Diseño de tres paneles (índice, editor y vista previa).
- Preparado para enlaces internos entre documentos.
