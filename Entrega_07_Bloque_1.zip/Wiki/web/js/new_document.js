function createDocument(){
 const cat=document.getElementById('category').value;
 const title=document.getElementById('title').value;
 alert('En la siguiente entrega se conectará con Python para generar el RFC de '+cat);
}
