import sqlite3
from pathlib import Path
from categories import DEFAULT_CATEGORIES
from document_types import DEFAULT_TYPES

DB=Path(__file__).parent/'wiki.db'
con=sqlite3.connect(DB)
c=con.cursor()
for cod,nom in DEFAULT_CATEGORIES:
    c.execute("INSERT OR IGNORE INTO categories(codigo,nombre) VALUES(?,?)",(cod,nom))
for nom,tpl in DEFAULT_TYPES:
    c.execute("INSERT OR IGNORE INTO document_types(nombre,plantilla) VALUES(?,?)",(nom,tpl))
con.commit()
con.close()
print("Datos iniciales cargados")
