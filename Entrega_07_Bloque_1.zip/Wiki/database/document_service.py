from datetime import datetime
from .rfc import next_rfc

def new_document(codigo_categoria,titulo,tipo):
    return {
        "rfc": next_rfc(codigo_categoria),
        "titulo": titulo,
        "categoria": codigo_categoria,
        "tipo": tipo,
        "version":"1.0",
        "estado":"Borrador",
        "fecha": datetime.now().strftime("%Y-%m-%d")
    }
