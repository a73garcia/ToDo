Entrega 28

- Registro de auditoría de acciones.
- Tabla audit_log.
- Panel de auditoría.
- Base para registrar crear, editar, restaurar y eliminar documentos.
