async function showAudit(rfc){
    console.log("Mostrar auditoría:", rfc);
    // Integración con API pendiente
}

function refreshAudit(){
    console.log("Actualizar panel de auditoría");
}
