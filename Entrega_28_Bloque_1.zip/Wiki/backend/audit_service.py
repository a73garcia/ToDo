import sqlite3
from pathlib import Path
from datetime import datetime

DB = Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def ensure_audit_table():
    con = sqlite3.connect(DB)
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS audit_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rfc TEXT,
        action TEXT,
        user TEXT,
        timestamp TEXT,
        details TEXT
    )
    """)
    con.commit()
    con.close()

def log_action(rfc, action, user, details=""):
    ensure_audit_table()
    con = sqlite3.connect(DB)
    cur = con.cursor()
    cur.execute(
        "INSERT INTO audit_log(rfc,action,user,timestamp,details) VALUES(?,?,?,?,?)",
        (rfc, action, user, datetime.now().isoformat(timespec="seconds"), details)
    )
    con.commit()
    con.close()
