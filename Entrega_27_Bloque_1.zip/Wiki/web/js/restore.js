async function restoreVersion(id){
    if(!confirm("¿Restaurar esta versión?")) return;
    console.log("Restaurar versión",id);
    // Llamada al backend en la siguiente integración.
}
