import sqlite3
from pathlib import Path

DB=Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def get_version(version_id):
    con=sqlite3.connect(DB)
    con.row_factory=sqlite3.Row
    cur=con.cursor()
    cur.execute("SELECT * FROM document_versions WHERE id=?",(version_id,))
    row=cur.fetchone()
    con.close()
    return dict(row) if row else None
