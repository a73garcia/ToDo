Entrega 27

- Servicio inicial para recuperar una versión.
- Diálogo de restauración.
- Acción JavaScript preparada para restaurar.
- Base para registrar la restauración como una nueva revisión.
