function exportDocument(format){
    console.log("Exportar documento:", format);
    // Integración con backend pendiente
}

function printDocument(){
    window.print();
}
