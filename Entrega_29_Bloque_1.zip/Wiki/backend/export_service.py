from pathlib import Path
from reportlab.platypus import SimpleDocTemplate, Preformatted
from reportlab.lib.styles import getSampleStyleSheet

def export_markdown(text, output):
    Path(output).write_text(text, encoding="utf-8")

def export_html(text, output):
    html=f"<html><body><pre>{text}</pre></body></html>"
    Path(output).write_text(html, encoding="utf-8")

def export_pdf(text, output):
    doc=SimpleDocTemplate(output)
    style=getSampleStyleSheet()["Code"]
    doc.build([Preformatted(text, style)])
