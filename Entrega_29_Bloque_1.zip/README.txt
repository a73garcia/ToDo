Entrega 29

- Exportación a Markdown, HTML y PDF.
- Menú de exportación.
- Hoja de estilos para impresión.
- Base preparada para exportación desde la interfaz.
