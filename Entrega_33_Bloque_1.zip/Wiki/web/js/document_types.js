function loadDocumentTypes(){
    console.log("Cargar tipos de documento");
}
function saveDocumentType(){
    console.log("Guardar tipo de documento");
}
function deleteDocumentType(id){
    console.log("Eliminar tipo",id);
}
