Entrega 33

- Gestión de tipos de documento.
- Tabla document_types.
- Asociación con plantillas Markdown.
- Base preparada para personalizar el editor según el tipo seleccionado.
