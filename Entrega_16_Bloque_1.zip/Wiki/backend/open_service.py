from pathlib import Path

DOCS = Path(__file__).resolve().parent.parent / "documents"

def load_markdown(rfc):
    file = DOCS / f"{rfc}.md"
    if not file.exists():
        return None
    return file.read_text(encoding="utf-8")
