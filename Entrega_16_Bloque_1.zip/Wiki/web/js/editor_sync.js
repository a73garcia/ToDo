async function openInEditor(rfc){
    const meta = await apiOpenDocument(rfc);

    if(meta.error){
        alert(meta.error);
        return;
    }

    document.getElementById("rfc").textContent = meta.rfc || "";
    document.getElementById("title").value = meta.titulo || "";
    document.getElementById("category").value = meta.categoria || "";
    document.getElementById("docType").value = meta.tipo || "";

    console.log("Pendiente cargar Markdown desde backend");
}

async function reloadList(){
    const docs = await apiGetDocuments();
    renderDocuments(docs);
}
