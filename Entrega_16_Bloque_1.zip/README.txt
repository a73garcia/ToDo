Entrega 16

- Servicio para abrir archivos Markdown.
- Sincronización inicial entre listado y editor.
- Diseño base de vista dividida (explorador + editor).
- Preparado para cargar el contenido completo del documento.
