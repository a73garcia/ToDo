from database.repository import list_documents,get_document

def api_list():
    return list_documents()

def api_open(rfc):
    return get_document(rfc)
