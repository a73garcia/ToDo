import sqlite3
from pathlib import Path

DB=Path(__file__).parent/'wiki.db'

def connection():
    return sqlite3.connect(DB)

def list_documents():
    con=connection()
    con.row_factory=sqlite3.Row
    cur=con.cursor()
    cur.execute("""SELECT rfc,titulo,categoria,tipo,
    '1.0' AS version,
    'Borrador' AS estado,
    '' AS fecha
    FROM documents
    ORDER BY rfc DESC""")
    rows=[dict(r) for r in cur.fetchall()]
    con.close()
    return rows

def get_document(rfc):
    con=connection()
    con.row_factory=sqlite3.Row
    cur=con.cursor()
    cur.execute("SELECT * FROM documents WHERE rfc=?",(rfc,))
    row=cur.fetchone()
    con.close()
    return dict(row) if row else None
