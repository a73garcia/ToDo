Entrega 10
- Repositorio SQLite para listar documentos.
- Apertura de documentos por RFC.
- API Python inicial para conectar el frontend.
En la siguiente entrega se implementará la edición completa y el guardado automático.
