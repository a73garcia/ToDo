from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse
from api import api_list, api_open
from editor_service import save_document
from delete_service import delete_document
import json

class Router(BaseHTTPRequestHandler):
    def _reply(self,obj,status=200):
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(obj,ensure_ascii=False).encode())

    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/api/documents":
            return self._reply(api_list())
        if path.startswith("/api/document/"):
            return self._reply(api_open(path.split("/")[-1]) or {},200)
        self._reply({"error":"Not found"},404)
