async function loadDocuments(){
 const docs=await apiGetDocuments();
 renderDocuments(docs);
}

async function openDocument(rfc){
 const doc=await apiOpenDocument(rfc);
 console.log(doc);
}

async function saveDocument(data){
 const res=await apiSave(data);
 if(res.success) await loadDocuments();
}

async function removeDocument(rfc){
 const res=await apiDelete(rfc);
 if(res.success) await loadDocuments();
}
