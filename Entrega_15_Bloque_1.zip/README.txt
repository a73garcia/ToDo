Entrega 15

- Router HTTP unificado.
- Integración del cliente CRUD.
- Actualización automática del listado tras guardar o eliminar.
Preparado para conectar la interfaz completa.
