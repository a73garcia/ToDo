import re
from pathlib import Path

DOCS = Path(__file__).resolve().parent.parent / "documents"

def find_backlinks(rfc):
    refs=[]
    if not DOCS.exists():
        return refs

    pattern=re.compile(r"\[\[(.*?)\]\]")

    for file in DOCS.glob("*.md"):
        text=file.read_text(encoding="utf-8", errors="ignore")
        if any(ref.strip()==rfc for ref in pattern.findall(text)):
            refs.append(file.stem)

    return sorted(refs)
