async function loadBacklinks(rfc){
    console.log("Cargar backlinks para:", rfc);
    // Integración con la API en la siguiente fase.
}

function renderBacklinks(list){
    const panel=document.getElementById("backlinks");
    if(!panel) return;

    panel.innerHTML="<h3>Referencias</h3>";

    if(list.length===0){
        panel.innerHTML+="<p>Sin referencias.</p>";
        return;
    }

    list.forEach(item=>{
        panel.innerHTML+=`<div class="backlink">${item}</div>`;
    });
}
