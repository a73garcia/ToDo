Entrega 21

- Sistema inicial de backlinks.
- Detección de documentos que enlazan mediante [[RFC]].
- Panel lateral para mostrar referencias.
- Base preparada para navegación bidireccional entre procedimientos.
