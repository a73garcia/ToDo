Entrega 18

- Vista dividida Editor / Previsualización.
- Renderizado Markdown básico en tiempo real.
- Preparado para incorporar resaltado de sintaxis y tabla de contenidos.
