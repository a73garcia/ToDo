
function escapeHtml(text){
    return text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function renderPreview(){
    const editor=document.getElementById("editor");
    const preview=document.getElementById("preview");
    if(!editor || !preview) return;

    let html=escapeHtml(editor.value)
        .replace(/^### (.*)$/gm,"<h3>$1</h3>")
        .replace(/^## (.*)$/gm,"<h2>$1</h2>")
        .replace(/^# (.*)$/gm,"<h1>$1</h1>")
        .replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>")
        .replace(/\*(.*?)\*/g,"<em>$1</em>")
        .replace(/\n/g,"<br>");

    preview.innerHTML=html;
}

window.addEventListener("DOMContentLoaded",()=>{
    const editor=document.getElementById("editor");
    if(editor){
        editor.addEventListener("input",renderPreview);
        renderPreview();
    }
});
