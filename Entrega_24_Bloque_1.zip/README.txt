Entrega 24

- Servicio para obtener etiquetas.
- Panel de etiquetas.
- Base para autocompletado y filtrado por múltiples etiquetas.
- Preparado para navegación temática.
