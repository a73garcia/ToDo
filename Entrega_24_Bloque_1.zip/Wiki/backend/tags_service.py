import sqlite3
from pathlib import Path

DB=Path(__file__).resolve().parent.parent/"database"/"wiki.db"

def get_tags():
    con=sqlite3.connect(DB)
    cur=con.cursor()
    try:
        cur.execute("SELECT DISTINCT etiquetas FROM documents")
        tags=set()
        for (value,) in cur.fetchall():
            if value:
                tags.update(t.strip() for t in value.split(",") if t.strip())
        return sorted(tags)
    finally:
        con.close()
