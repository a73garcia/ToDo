
let availableTags=[];

function filterByTag(tag){
    console.log("Filtrar por etiqueta:",tag);
}

function renderTagSuggestions(tags){
    availableTags=tags;
    console.log("Etiquetas disponibles:",tags);
}
