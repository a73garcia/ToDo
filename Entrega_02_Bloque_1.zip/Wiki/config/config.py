APP_NAME="Wiki Procedimientos"
VERSION="1.0"
DB_NAME="wiki.db"
HOST="127.0.0.1"
PORT=8080
