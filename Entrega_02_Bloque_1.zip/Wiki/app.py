"""
Punto de entrada de la aplicación Wiki.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

def create_app():
    return {
        "name": "Wiki Procedimientos",
        "version": "1.0",
        "base_dir": str(BASE_DIR)
    }

if __name__ == "__main__":
    print(create_app())
