import sqlite3
from pathlib import Path

DB=Path(__file__).resolve().parent/"wiki.db"

def get_connection():
    return sqlite3.connect(DB)
