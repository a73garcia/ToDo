SCHEMA = {
"categories":["id","codigo","nombre","descripcion","color","activa"],
"document_types":["id","nombre","plantilla"],
"documents":["id","rfc","titulo","categoria","tipo"]
}
