Entrega 23

- Búsqueda dentro del contenido Markdown.
- Resaltado visual de coincidencias.
- Panel preparado para mostrar resultados.
- Base para búsqueda en etiquetas y enlaces Wiki.
