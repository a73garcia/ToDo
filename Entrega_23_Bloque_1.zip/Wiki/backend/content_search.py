from pathlib import Path
import re

DOCS=Path(__file__).resolve().parent.parent/"documents"

def search_content(text):
    results=[]
    if not DOCS.exists():
        return results
    rx=re.compile(re.escape(text),re.IGNORECASE)
    for f in DOCS.glob("*.md"):
        c=f.read_text(encoding="utf-8",errors="ignore")
        if rx.search(c):
            results.append({"rfc":f.stem,"matches":len(rx.findall(c))})
    return sorted(results,key=lambda x:x["matches"],reverse=True)
