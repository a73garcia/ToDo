\
function highlightMatches(html,text){
 if(!text) return html;
 const rx=new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"gi");
 return html.replace(rx,m=>`<mark>${m}</mark>`);
}
