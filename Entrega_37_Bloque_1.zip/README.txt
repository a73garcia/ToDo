Entrega 37

- Detección de enlaces wiki [[RFC]].
- Tabla document_links.
- Panel de relaciones entre documentos.
- Base preparada para backlinks y navegación contextual.
