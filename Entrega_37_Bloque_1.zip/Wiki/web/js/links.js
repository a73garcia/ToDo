function showBacklinks(rfc){
    console.log("Mostrar backlinks:",rfc);
}
function openLinkedDocument(rfc){
    console.log("Abrir documento:",rfc);
}
function refreshLinks(){
    console.log("Actualizar relaciones");
}
