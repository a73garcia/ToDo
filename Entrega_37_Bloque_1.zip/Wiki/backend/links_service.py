import sqlite3
from pathlib import Path
import re

DB = Path(__file__).resolve().parent.parent/"database"/"wiki.db"

WIKI_LINK = re.compile(r"\[\[([^\]]+)\]\]")

def extract_links(markdown):
    return WIKI_LINK.findall(markdown)

def ensure_table():
    con=sqlite3.connect(DB)
    con.execute('''
    CREATE TABLE IF NOT EXISTS document_links(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_rfc TEXT NOT NULL,
        target_rfc TEXT NOT NULL
    )
    ''')
    con.commit()
    con.close()
