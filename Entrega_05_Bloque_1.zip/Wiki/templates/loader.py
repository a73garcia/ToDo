from pathlib import Path

TEMPLATE_DIR = Path(__file__).resolve().parent

def load_template(name:str)->str:
    path = TEMPLATE_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(path)
    return path.read_text(encoding="utf-8")
