RFC            :
Título         :
Plataforma     :
Fecha          :
Autor          :

# OBJETIVO

# QUERY

```spl

```

# RESULTADO ESPERADO

# OBSERVACIONES
