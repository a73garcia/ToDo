Entrega 14

- Endpoints POST /api/save y /api/delete.
- Cliente JavaScript para guardar y eliminar documentos.
- Base preparada para completar el flujo CRUD local.
