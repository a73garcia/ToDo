import json
from http.server import BaseHTTPRequestHandler
from editor_service import save_document
from delete_service import delete_document

class WikiPostAPI(BaseHTTPRequestHandler):

    def _json(self):
        length=int(self.headers.get("Content-Length",0))
        if length==0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def _send(self,data,code=200):
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data,ensure_ascii=False).encode("utf-8"))

    def do_POST(self):

        if self.path=="/api/save":
            d=self._json()
            ok=save_document(
                d["rfc"],
                d["title"],
                d["category"],
                d["type"],
                d["content"]
            )
            self._send({"success":ok})
            return

        if self.path=="/api/delete":
            d=self._json()
            ok=delete_document(d["rfc"])
            self._send({"success":ok})
            return

        self._send({"error":"Ruta no válida"},404)
