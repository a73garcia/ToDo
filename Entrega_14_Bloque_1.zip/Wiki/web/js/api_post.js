async function apiSave(data){
    const r=await fetch("/api/save",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(data)
    });
    return await r.json();
}

async function apiDelete(rfc){
    const r=await fetch("/api/delete",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({rfc:rfc})
    });
    return await r.json();
}
