Entrega 06
-----------
Añade la carga automática de plantillas según el tipo de documento.
Incluye el parche necesario para index.html y el JavaScript inicial.
