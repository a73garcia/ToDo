const TEMPLATE_MAP={
'Documentación':'documentacion',
'Query':'query',
'Script':'script',
'Correo':'correo',
'Respuesta':'respuesta'
};

async function loadTemplate(){
 const sel=document.getElementById('docType');
 const editor=document.getElementById('editor');
 const name=TEMPLATE_MAP[sel.value];
 const rsp=await fetch('../templates/'+name+'.md');
 editor.value=await rsp.text();
}

function setRFC(rfc){
 const el=document.getElementById('rfc');
 if(el) el.textContent=rfc;
}

window.addEventListener('DOMContentLoaded',()=>{
 const sel=document.getElementById('docType');
 if(sel){
   sel.addEventListener('change',loadTemplate);
   loadTemplate();
 }
});
