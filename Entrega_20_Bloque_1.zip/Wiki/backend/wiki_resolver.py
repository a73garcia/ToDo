from database.repository import get_document

def resolve_reference(reference):
    doc=get_document(reference)
    if doc:
        return doc
    return None
