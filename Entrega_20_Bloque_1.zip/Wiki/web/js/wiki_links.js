
function renderWikiLinks(html){
    return html.replace(/\[\[(.*?)\]\]/g,
        '<a class="wiki-link" href="#" data-ref="$1">$1</a>');
}

document.addEventListener("click",async function(e){
    if(e.target.classList.contains("wiki-link")){
        e.preventDefault();
        const ref=e.target.dataset.ref;
        console.log("Abrir documento:",ref);
        // Integración con apiOpenDocument() en la siguiente fase
    }
});
