Entrega 20

- Soporte inicial para enlaces Wiki [[RFC]] y [[Título]].
- Estilos para enlaces existentes y pendientes.
- Resolver Python para localizar documentos enlazados.
- Preparado para navegación entre procedimientos.
