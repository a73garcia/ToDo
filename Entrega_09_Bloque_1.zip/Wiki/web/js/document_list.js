const documents=[];

function renderDocuments(rows=documents){
 const body=document.querySelector('#documentTable tbody');
 if(!body) return;
 body.innerHTML='';
 rows.forEach(d=>{
   body.insertAdjacentHTML('beforeend',
   `<tr>
      <td>${d.rfc}</td>
      <td>${d.title}</td>
      <td>${d.category}</td>
      <td>${d.type}</td>
      <td>${d.version}</td>
      <td>${d.status}</td>
      <td>${d.date}</td>
    </tr>`);
 });
}

function searchDocuments(){
 const txt=document.getElementById('search').value.toLowerCase();
 renderDocuments(documents.filter(d=>
   d.rfc.toLowerCase().includes(txt) ||
   d.title.toLowerCase().includes(txt) ||
   (d.tags||'').toLowerCase().includes(txt)
 ));
}

window.addEventListener('DOMContentLoaded',()=>{
 const b=document.getElementById('btnSearch');
 if(b) b.addEventListener('click',searchDocuments);
});
