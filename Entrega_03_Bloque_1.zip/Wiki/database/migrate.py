import sqlite3
from pathlib import Path

DB=Path(__file__).parent/"wiki.db"

SQL=[
"""CREATE TABLE IF NOT EXISTS categories(
id INTEGER PRIMARY KEY,
codigo TEXT UNIQUE NOT NULL,
nombre TEXT NOT NULL,
descripcion TEXT,
color TEXT,
activa INTEGER DEFAULT 1
);""",
"""CREATE TABLE IF NOT EXISTS document_types(
id INTEGER PRIMARY KEY,
nombre TEXT UNIQUE,
plantilla TEXT
);""",
"""CREATE TABLE IF NOT EXISTS rfc_counter(
codigo TEXT,
fecha TEXT,
ultimo INTEGER,
PRIMARY KEY(codigo,fecha)
);""",
"""CREATE TABLE IF NOT EXISTS documents(
id INTEGER PRIMARY KEY,
rfc TEXT UNIQUE,
titulo TEXT,
categoria TEXT,
tipo TEXT
);"""
]

def migrate():
    con=sqlite3.connect(DB)
    cur=con.cursor()
    for s in SQL:
        cur.execute(s)
    con.commit()
    con.close()

if __name__=="__main__":
    migrate()
