DEFAULT_CATEGORIES=[
("GEN","General"),
("SPL","Splunk"),
("ESA","Cisco ESA"),
("PPF","Proofpoint"),
("PYT","Python"),
("PWA","Power Automate"),
]
