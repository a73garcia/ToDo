DEFAULT_TYPES=[
("Documentación","documentacion.md"),
("Query","query.md"),
("Script","script.md"),
("Correo","correo.md"),
("Respuesta","respuesta.md"),
]
