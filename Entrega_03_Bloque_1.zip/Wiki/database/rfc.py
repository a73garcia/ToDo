from datetime import datetime
import sqlite3
from pathlib import Path
DB=Path(__file__).parent/"wiki.db"

def next_rfc(codigo):
    fecha=datetime.now().strftime("%y%m%d")
    con=sqlite3.connect(DB)
    c=con.cursor()
    c.execute("SELECT ultimo FROM rfc_counter WHERE codigo=? AND fecha=?",(codigo,fecha))
    row=c.fetchone()
    n=1 if row is None else row[0]+1
    c.execute("INSERT OR REPLACE INTO rfc_counter(codigo,fecha,ultimo) VALUES(?,?,?)",(codigo,fecha,n))
    con.commit(); con.close()
    return f"{codigo}-{fecha}-{n:05d}"
